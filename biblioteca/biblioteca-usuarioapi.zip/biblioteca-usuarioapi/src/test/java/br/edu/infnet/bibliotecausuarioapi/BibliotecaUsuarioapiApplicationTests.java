package br.edu.infnet.bibliotecausuarioapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaUsuarioapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
